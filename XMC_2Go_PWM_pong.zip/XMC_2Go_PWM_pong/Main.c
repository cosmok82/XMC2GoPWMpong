/*=========================================================================== *
 * Copyright (c) 2013, CREATIVITYslashDESIGN.tk                                *
 * All rights reserved.                                                        *
 *                                                                             *
 * Redistribution and use in source and binary forms, with or without          *
 * modification, are permitted provided that the following conditions are met: *
 * Redistributions of source code must retain the above copyright notice, this *
 * list of conditions and the following disclaimer. Redistributions in binary  *
 * form must reproduce the above copyright notice, this list of conditions and *
 * the following disclaimer in the documentation and/or other materials        *
 * provided with the distribution. Neither the name of the copyright holders   *
 * nor the names of its contributors may be used to endorse or promote         *
 * products derived from this software without specific prior written          *
 * permission.                                                                 *
 *                                                                             *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" *
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,       *
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR      *
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR           *
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,       *
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,         *
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; *
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,    *
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR     *
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF      *
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.                                  *
 * To improve the quality of the software, users are encouraged to share       *
 * modifications, enhancements or bug fixes with                               *
 * CREATIVITYslashDESIGN.tk (cosmok82@gmail.com or							   *
 * creativityslashdesign@gmail.com).										   *
 *                                                                             *
 * ========================================================================== */

/*******************************************************************************
**                                                                            **
**                                                                            **
** PLATFORM : Infineon XMC1100 XMC 2Go                                        **
**                                                                            **
** AUTHOR : CREATIVITYslashDESIGN.tk (Engineer Cosimo Orlando)		          **
**                                                                            **
** Version 1.0.0 (Initial version)                        	  				  **
**                                                                            **
** MODIFICATION DATE : May 14, 2014                                           **
**                                                                            **
*******************************************************************************/



#include <DAVE3.h>		//Declarations from DAVE3 Code Generation (includes SFR declaration)

/**
 * @brief main function
 * @param[in] None
 * @return None
 */
int main(void)
{
	DAVE_Init();		// Initialization of DAVE Apps

	/* Starts the PWMSP001 App (LEDs) */
	PWMSP001_Start(&PWMSP001_Handle0);
	PWMSP001_Start(&PWMSP001_Handle1);

	while(1)
	{

	}
	return 0;
}


/**
 * @brief PWM_Period_Interrupt handler: executes every period match of
 * PWMSP001/0 & PWMSP001/1.
 * @param[in] None
 * @return None
 */
void PWM_Period_Interrupt(void)
{
	uint32_t state;
	uint16_t rate;
	status_t Status0;
	status_t Status1;

	if(state%10 == 0) //define when the Duty Cycle will be updated, every 10 cycle
	{
		Status0 = PWMSP001_SetDutyCycle((PWMSP001_HandleType*)&PWMSP001_Handle0, rate); // LED1
		Status1 = PWMSP001_SetDutyCycle((PWMSP001_HandleType*)&PWMSP001_Handle1, 100-rate); // LED2
		rate++;
	}

	// Updating of the state machine (within 10000 cycles)
	state++;

	if(state>=10000) state = 0;
	if(rate>=100)	 rate  = 0;
}
